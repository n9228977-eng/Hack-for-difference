// server/routes/register.js
import { Router } from "express";
import { emptyCandidate } from "../schema.js";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { v4 as uuid } from "uuid";

const r = Router();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Ensure both the storage and data directories exist
const storageDir = path.join(__dirname, "..", "storage");
const dataDir = path.join(storageDir, "data");
const dataPath = path.join(dataDir, "candidates.json");

// Helper: ensure directory and file exist
function ensureDataFile() {
  if (!fs.existsSync(storageDir)) fs.mkdirSync(storageDir);
  if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir);
  if (!fs.existsSync(dataPath)) fs.writeFileSync(dataPath, JSON.stringify([]));
}

function loadDb() {
  ensureDataFile();
  return JSON.parse(fs.readFileSync(dataPath, "utf-8"));
}

r.post("/", (req, res) => {
  try {
    const { consent } = req.body || {};
    const id = uuid();

    const base = emptyCandidate();
    base.audit.consent_captured = !!consent;

    const db = loadDb();
    db.push({ id, candidate: base });
    fs.writeFileSync(dataPath, JSON.stringify(db, null, 2));

    res.json({ sessionId: id });
  } catch (err) {
    console.error("REGISTER ERROR:", err);
    res.status(500).json({ error: "register_failed", message: err.message });
  }
});

export default r;