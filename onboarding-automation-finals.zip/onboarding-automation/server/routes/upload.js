import { Router } from "express";
import multer from "multer";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import mammoth from "mammoth";      // .docx text extraction
import { createRequire } from "module"; // <-- CJS interop for pdf-parse
const require = createRequire(import.meta.url);
const pdfParse = require("pdf-parse");   // <-- Safe way to use pdf-parse in ESM

const r = Router();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const uploadRoot = path.join(__dirname, "..", "storage", "uploads");

if (!fs.existsSync(uploadRoot)) fs.mkdirSync(uploadRoot, { recursive: true });

/* ----------------------------
 * Helpers: extensions
 * ---------------------------- */
function safeImageExt(original) {
  const ext = (path.extname(original) || "").toLowerCase();
  if ([".jpg", ".jpeg", ".png", ".webp"].includes(ext)) return ext;
  return ".jpg";
}

function safeTranscriptExt(original) {
  const ext = (path.extname(original) || "").toLowerCase();
  const allowed = [".txt", ".doc", ".docx", ".pdf", ".rtf"];
  return allowed.includes(ext) ? ext : ".txt";
}

/* ----------------------------
 * Minimal RTF -> text (naive; good enough for transcripts)
 * ---------------------------- */
function rtfToText(rtf) {
  return rtf
    .replace(/\\par[d]?/g, "\n")
    .replace(/\\'([0-9a-fA-F]{2})/g, (_, hex) =>
      String.fromCharCode(parseInt(hex, 16))
    )
    .replace(/\\[a-z]+\d* ?/g, "")
    .replace(/[{}]/g, "");
}

/* ----------------------------
 * Text extraction (local only)
 * - TXT: read as UTF-8
 * - DOCX: mammoth
 * - PDF: pdf-parse (via createRequire interop)
 * - RTF: naive cleanup
 * - DOC: best-effort UTF-8 read (legacy .doc may not parse reliably)
 * ---------------------------- */
async function extractTextLocally(filePath) {
  const ext = path.extname(filePath).toLowerCase();

  // ---- TXT ----
  if (ext === ".txt") {
    return fs.readFileSync(filePath, "utf8");
  }

  // ---- DOCX ----
  if (ext === ".docx") {
    const { value } = await mammoth.extractRawText({ path: filePath });
    return value || "";
  }

  // ---- PDF ----
  if (ext === ".pdf") {
    const buffer = fs.readFileSync(filePath);
    const data = await pdfParse(buffer);
    return data.text || "";
  }

  // ---- RTF ----
  if (ext === ".rtf") {
    const raw = fs.readFileSync(filePath, "utf8");
    return rtfToText(raw);
  }

  // ---- DOC (legacy; best-effort)
  try {
    return fs.readFileSync(filePath, "utf8");
  } catch {
    return "";
  }
}

/* ----------------------------
 * Multer storage
 * ---------------------------- */
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const { sessionId } = req.body;
    if (!sessionId) return cb(new Error("Missing sessionId"), "");
    const sessDir = path.join(uploadRoot, sessionId);
    if (!fs.existsSync(sessDir)) fs.mkdirSync(sessDir, { recursive: true });
    cb(null, sessDir);
  },
  filename: (req, file, cb) => {
    if (file.fieldname === "passport_photo") {
      return cb(null, "passport" + safeImageExt(file.originalname));
    }
    if (file.fieldname === "transcript_file") {
      return cb(null, "transcript" + safeTranscriptExt(file.originalname));
    }
    const name = Date.now() + "-" + file.originalname;
    cb(null, name);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 50 * 1024 * 1024 } // up to 50MB
});

/* ----------------------------
 * Route: store files, extract text locally for preview
 * ---------------------------- */
r.post(
  "/",
  upload.fields([
    { name: "docs", maxCount: 20 },
    { name: "passport_photo", maxCount: 1 },
    { name: "transcript_file", maxCount: 1 }
  ]),
  async (req, res) => {
    try {
      const { sessionId } = req.body;
      if (!sessionId) {
        return res.status(400).json({ ok: false, error: "Missing sessionId" });
      }

      // List docs (unchanged behavior)
      const docs = (req.files?.docs || []).map(f => ({
        path: f.path,
        originalname: f.originalname,
        mimetype: f.mimetype,
        size: f.size
      }));

      let transcript = null;

      // Handle transcript file (TXT, DOCX, PDF, RTF, DOC best-effort)
      const tf = req.files?.transcript_file?.[0];
      if (tf?.path) {
        // Extract plain text locally so UI can preview (AI runs later in /api/parse)
        const plainTextRaw = (await extractTextLocally(tf.path)) || "";

        // Hard truncate very large files to keep UI responsive (adjust as needed)
        const MAX_CHARS = 100_000;
        const plainText =
          plainTextRaw.length > MAX_CHARS
            ? plainTextRaw.slice(0, MAX_CHARS) + "\n\n[Truncated for preview…]"
            : plainTextRaw;

        transcript = {
          speakers: null,       // AI (in /api/parse) will fill this
          transcript: null,     // AI (in /api/parse) will fill this
          summary: null,        // AI (in /api/parse) will fill this
          plain_text: plainText // preview string only
        };
      }

      return res.json({ ok: true, uploaded: docs, transcript });
    } catch (err) {
      console.error("Upload route error:", err);
      return res.status(500).json({ ok: false, error: "upload_failed" });
    }
  }
);

export default r;