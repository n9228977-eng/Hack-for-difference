// server/routes/parse.js

// server/routes/parse.js
import { Router } from "express";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

// ESM-safe imports for DOCX + PDF
import mammoth from "mammoth";
import { createRequire } from "module";
const require = createRequire(import.meta.url);
const pdfParse = require("pdf-parse");   // <-- 

import client from "../openaiClient.js";
import { mergePartials } from "../merge.js";
import { emptyCandidate } from "../schema.js";

const r = Router();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/* ============================================================
 * IMAGE → STRUCTURED DATA (existing)
 * ============================================================ */

const SYSTEM_VISION = `
You extract data from Indian identity docs, 10th/12th marksheets, and certificates.

Return ONE STRICT JSON object only. No markdown, no prose. If a field is missing, return:
{"value": null, "source": null, "confidence": 0.0}

SCHEMA:
{
 "identity": {
   "full_name": {"value","source","confidence"},
   "dob": {"value","source","confidence"},
   "gender": {"value","source","confidence"},
   "photo_b64": {"value","source","confidence"}
 },
 "ids": {
   "aadhaar_last4": {"value","source","confidence"},
   "pan": {"value","source","confidence"},
   "dl_number": {"value","source","confidence"},
   "epic_number": {"value","source","confidence"},
   "passport_no": {"value","source","confidence"}
 },
 "address": {
   "full_address": {"value","source","confidence"},
   "pincode": {"value","source","confidence"},
   "state": {"value","source","confidence"},
   "district": {"value","source","confidence"}
 },
 "education": [
   {
     "level": "10th|12th|Diploma|Degree",
     "board_university": {"value","source","confidence"},
     "exam_year": {"value","source","confidence"},
     "roll_or_enrollment": {"value","source","confidence"},
     "cgpa_or_percent": {"value","source","confidence"}
   }
 ],
 "skills_certifications": [
   {
     "certificate_title": {"value","source","confidence"},
     "issuing_org": {"value","source","confidence"},
     "issue_date": {"value","source","confidence"},
     "cert_id": {"value","source","confidence"},
     "skill_detected": {"value","source","confidence"},
     "grade_or_score": {"value","source","confidence"}
   }
 ],
 "financial_optional": { "bank_name":{"value","source","confidence"}, "branch":{"value","source","confidence"}, "ifsc":{"value","source","confidence"}, "account_last4":{"value","source","confidence"} },
 "social_protection_optional": { "e_shram_uan":{"value","source","confidence"}, "apprenticeship_contract_id":{"value","source","confidence"} }
}

RULES:
- Set "source" to a sensible doc type: "marksheet", "certificate", "pan", "dl", etc.
- Confidence 0..1. Do NOT output full Aadhaar/bank numbers; only last4 where visible.
- If this is a 12th marksheet:
    • level="12th"
    • board_university.value should be the board name (e.g., CBSE, BSEB)
    • fill exam_year, roll_or_enrollment
    • For cgpa_or_percent:
        - If an overall "Result/Percentage/CGPA" line is present, use it.
        - Otherwise, compute percentage = (sum of obtained marks) / (sum of maximum marks) * 100 and round to 2 decimals, append "%" (e.g., "82.40%").
- Respond with exactly one JSON object compliant with SCHEMA. No extra text.
`;

function fileToB64(filePath) {
  return fs.readFileSync(filePath).toString("base64");
}

function guessMime(fp) {
  const ext = path.extname(fp).toLowerCase();
  if (ext === ".png") return "image/png";
  if (ext === ".webp") return "image/webp";
  return "image/jpeg"; // default for jpg/jpeg
}

function extractJsonFromLLM(text) {
  if (!text) return null;
  const start = text.indexOf("{");
  const end = text.lastIndexOf("}");
  if (start === -1 || end === -1 || end <= start) return null;
  return text.slice(start, end + 1);
}

/* ============================================================
 * TRANSCRIPT → SUMMARY + SCORING (NEW)
 * ============================================================ */

// Local text extraction (same approach as in upload)
function rtfToText(rtf) {
  return rtf
    .replace(/\\par[d]?/g, "\n")
    .replace(/\\'([0-9a-fA-F]{2})/g, (_, hex) => String.fromCharCode(parseInt(hex, 16)))
    .replace(/\\[a-z]+\d* ?/g, "")
    .replace(/[{}]/g, "");
}

async function extractPlainText(filePath) {
  const ext = path.extname(filePath).toLowerCase();

  // TXT
  if (ext === ".txt") {
    return fs.readFileSync(filePath, "utf8");
  }

  // DOCX
  if (ext === ".docx") {
    const { value } = await mammoth.extractRawText({ path: filePath });
    return value || "";
  }

  // PDF
  if (ext === ".pdf") {
    const buffer = fs.readFileSync(filePath);
    const data = await pdfParse(buffer);
    return data.text || "";
  }

  // RTF
  if (ext === ".rtf") {
    const raw = fs.readFileSync(filePath, "utf8");
    return rtfToText(raw);
  }

  // DOC (legacy; best-effort)
  try {
    return fs.readFileSync(filePath, "utf8");
  } catch {
    return "";
  }
}

function locateTranscriptFile(sessDir) {
  // Look for files named "transcript" with common extensions
  const candidates = fs.readdirSync(sessDir);
  const exts = [".txt", ".docx", ".pdf", ".rtf", ".doc"];
  for (const name of candidates) {
    const lower = name.toLowerCase();
    if (!lower.startsWith("transcript")) continue;
    const ext = path.extname(lower);
    if (exts.includes(ext)) {
      return path.join(sessDir, name);
    }
  }
  // Fallback: any one non-image file as transcript
  const anyDoc = candidates.find(n => /\.(txt|docx|pdf|rtf|doc)$/i.test(n));
  return anyDoc ? path.join(sessDir, anyDoc) : null;
}

const SYSTEM_TRANSCRIPT = `
You are an assessor for a youth employability NGO. Read the transcript (R=Representative, Y=Youth).
Output STRICT JSON ONLY with fields: summary, scores[], total, eligibility{status, thresholds, reason}.

Categories (each 0–20):
- Motivation & Intent
- Consistency Evidence
- Logistics & Mobility Fit
- Program Awareness & Commitment
- Risk & Mitigation Readiness

Rules:
- Eligible if total >= 70, Conditional if 60–69, else Not Eligible.
- Keep summary to 1–2 sentences.
- Each score must include an "explanation" citing evidence from the transcript.
- Return ONLY valid JSON (no markdown, no prose).
`;

async function analyzeTranscriptWithChat(rawText) {
  // Call Azure OpenAI Chat Completions — content must be STRING
  const completion = await client.chat.completions.create({
    model: process.env.AZURE_OPENAI_DEPLOYMENT, // your Azure deployment name (e.g., gpt-4.1-mini)
    messages: [
      { role: "system", content: SYSTEM_TRANSCRIPT },
      { role: "user", content: `TRANSCRIPT:\n${rawText}\n\nReturn valid JSON only.` }
    ],
    temperature: 0.2
  });

  const raw = (completion?.choices?.[0]?.message?.content || "").trim();
  let analysis;
  try {
    analysis = JSON.parse(raw);
  } catch {
    // Fallback minimal analysis
    analysis = {
      summary: "Analysis unavailable.",
      scores: [],
      total: 0,
      eligibility: { status: "CONDITIONAL", thresholds: { eligible: 70, conditional: 60 }, reason: "Model returned malformed JSON; manual review required." }
    };
  }

  // Ensure totals/eligibility present
  if (Array.isArray(analysis.scores)) {
    analysis.total = analysis.scores.reduce((sum, s) => sum + (+s.score || 0), 0);
    const thr = analysis.eligibility?.thresholds || { eligible: 70, conditional: 60 };
    const status = analysis.eligibility?.status
      || (analysis.total >= thr.eligible ? "ELIGIBLE" : analysis.total >= thr.conditional ? "CONDITIONAL" : "NOT_ELIGIBLE");
    analysis.eligibility = {
      status,
      thresholds: thr,
      reason: analysis.eligibility?.reason || "Decision inferred from rubric thresholds."
    };
  }

  return analysis;
}

/* ============================================================
 * ROUTE
 * ============================================================ */

r.post("/", async (req, res) => {
  try {
    const { sessionId } = req.body;
    const sessDir = path.join(__dirname, "..", "storage", "uploads", sessionId);
    if (!fs.existsSync(sessDir)) {
      return res.status(400).json({ error: "No uploads for this session" });
    }

    /* ---- 1) Parse document IMAGES (existing logic) ---- */
    const allFiles = fs.readdirSync(sessDir).filter(n => /\.(png|jpg|jpeg|webp)$/i.test(n));

    // Skip the dedicated passport photo file from parsing
    const passportFileName = allFiles.find(n => /^passport\.(jpg|jpeg|png|webp)$/i.test(n));
    const docFiles = allFiles.filter(n => n !== passportFileName);

    const partials = [];
    const docSources = [];

    if (docFiles.length > 0) {
      console.log("Calling Chat Completions (vision via image_url) with deployment:", process.env.AZURE_OPENAI_DEPLOYMENT);

      for (const n of docFiles) {
        const fp = path.join(sessDir, n);
        const mime = guessMime(fp);
        const b64 = fileToB64(fp);

        const resp = await client.chat.completions.create({
          model: process.env.AZURE_OPENAI_DEPLOYMENT,   // gpt-4o or deployment supporting image_url in chat
          temperature: 0,
          max_tokens: 1600,
          messages: [
            { role: "system", content: SYSTEM_VISION },
            {
              role: "user",
              content: [
                { type: "text", text: "Extract fields from this document image. Return STRICT JSON only." },
                { type: "image_url", image_url: { url: `data:${mime};base64,${b64}`, detail: "auto" } }
              ]
            }
          ]
        });

        const raw = (resp.choices?.[0]?.message?.content || "").trim();
        const jsonText = extractJsonFromLLM(raw);

        if (!jsonText) {
          console.warn("Model did not return JSON. First 200 chars:", raw.slice(0, 200));
          partials.push({});
        } else {
          try {
            const parsed = JSON.parse(jsonText);
            partials.push(parsed);
          } catch (e) {
            console.warn("JSON parse error. First 200 chars:", jsonText.slice(0, 200));
            partials.push({});
          }
        }
        docSources.push(n);
      }
    }

    // Merge via LLM
    const audit = {
      doc_sources: docSources,
      created_at: new Date().toISOString(),
      consent_captured: true
    };
    const merged = await mergePartials(partials, audit);
    const candidate = merged && typeof merged === "object" ? merged : emptyCandidate();

    // Inject passport photo path if present
    if (passportFileName) {
      const pPath = path.join(sessDir, passportFileName);
      candidate.identity = candidate.identity || {};
      candidate.identity.photo_path = { value: pPath, source: "user_upload", confidence: 1 };
      // keep photo_b64 from OCR if it exists; no need to overwrite
    }

    /* ---- 2) Parse TRANSCRIPT file (NEW) ---- */
    let analysis = null;
    let transcriptObj = null;

    const transcriptPath = locateTranscriptFile(sessDir);
    if (transcriptPath) {
      const rawText = (await extractPlainText(transcriptPath)).trim();
      if (rawText) {
        console.log("Calling Chat Completions (transcript analysis) with deployment:", process.env.AZURE_OPENAI_DEPLOYMENT);
        analysis = await analyzeTranscriptWithChat(rawText);
        transcriptObj = { plain_text: rawText };
      } else {
        console.warn("Transcript exists but no readable text:", transcriptPath);
        analysis = {
          summary: "Transcript text could not be extracted.",
          scores: [],
          total: 0,
          eligibility: { status: "CONDITIONAL", thresholds: { eligible: 70, conditional: 60 }, reason: "No readable transcript; manual review required." }
        };
        transcriptObj = { plain_text: "" };
      }
    } else {
      console.warn("No transcript file found in session directory:", sessDir);
      // It's okay to proceed without analysis; frontend can still show candidate fields
      analysis = null;
      transcriptObj = null;
    }

    /* ---- 3) Respond ---- */
    console.log("MERGED education", candidate?.education?.[0]);

    return res.json({
      partialsCount: partials.length,
      candidate,
      analysis,         // NEW: summary + scores + eligibility (may be null if no transcript)
      transcript: transcriptObj // NEW: { plain_text } (may be null)
    });

  } catch (err) {
    console.error("PARSE ERROR:", err);
    return res.status(500).json({ error: "Parse failed", details: err.message });
  }
});

export default r;