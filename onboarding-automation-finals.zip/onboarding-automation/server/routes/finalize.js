import { Router } from "express";
import fs from "fs";
import path from "path";
import XLSX from "xlsx";
import { fileURLToPath } from "url";
import { CandidateSchema } from "../schema.js";
import { getLocalityFromPin } from "../utils/localityFromPin.js";
import { findNearestCenter } from "../utils/nearestCenter.js";
import { verifyFaces } from "../utils/faceVerify.js";   // OpenAI-only verifier
import client from "../openaiClient.js";                 // Azure OpenAI client

const r = Router();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const excelPath = path.join(__dirname, "..", "storage", "data", "students.xlsx");
const uploadsRoot = path.join(__dirname, "..", "storage", "uploads");

// ---------- Helpers ----------
function ensureExcel() {
  if (!fs.existsSync(excelPath)) {
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet([]);
    XLSX.utils.book_append_sheet(wb, ws, "Students");
    XLSX.writeFile(wb, excelPath);
  }
}

function ensureSheet(wb, name) {
  if (!wb.Sheets[name]) {
    const ws = XLSX.utils.json_to_sheet([]);
    XLSX.utils.book_append_sheet(wb, ws, name);
  }
}

function findVoiceInSession(sessionId) {
  try {
    const dir = path.join(uploadsRoot, sessionId);
    const voicePath = path.join(dir, "voice.webm");
    return fs.existsSync(voicePath) ? voicePath : "";
  } catch {
    return "";
  }
}

// Build concise summary
async function buildSummary(candidate, nearestCenterName) {
  const name  = candidate.identity.full_name?.value || "The candidate";
  const dob   = candidate.identity.dob?.value || "";
  const edu   = candidate.education?.[0];
  const level = edu?.level || "";
  const percent = edu?.cgpa_or_percent?.value || "";
  const skill = candidate.skills_certifications?.[0]?.skill_detected?.value || "";
  const certTitle = candidate.skills_certifications?.[0]?.certificate_title?.value || "";
  const cityOrPin = candidate.address?.pincode?.value || "";

  const system = `Write a 1-3 short lines summary (<= 350 chars) suitable for an Excel cell. Be factual, no emojis.`;
  const user   = `
Name: ${name}
DOB: ${dob}
Education: ${level} (${percent})
Certificate: ${certTitle}
Skill: ${skill}
Pincode: ${cityOrPin}
NearestCenter: ${nearestCenterName}
Goal: Summarize the candidate for a coordinator to triage quickly.
`;

  try {
    const resp = await client.chat.completions.create({
      model: process.env.AZURE_OPENAI_DEPLOYMENT,
      temperature: 0.2,
      max_tokens: 120,
      messages: [
        { role: "system", content: system },
        { role: "user", content: user }
      ]
    });
    return (resp.choices?.[0]?.message?.content || "")
      .trim()
      .replace(/\s+/g, " ");
  } catch (e) {
    console.error("SUMMARY ERROR:", e.message);
    return `${name} - ${level || "Education N/A"}${percent ? " ("+percent+")" : ""}${skill ? " | Skill: "+skill : ""} | Nearest: ${nearestCenterName}`;
  }
}

// ---------- Image resolution helpers (robust with session fallbacks) ----------
function findPassportInSession(sessionId) {
  try {
    const dir = path.join(uploadsRoot, sessionId);
    if (!fs.existsSync(dir)) return null;
    const names = fs.readdirSync(dir).filter(n => /\.(png|jpg|jpeg|webp)$/i.test(n));
    const passport = names.find(n => /^passport\.(jpg|jpeg|png|webp)$/i.test(n));
    return passport ? { kind: "path", value: path.join(dir, passport) } : null;
  } catch {
    return null;
  }
}

function resolvePassport(data, sessionId) {
  // Prefer explicit path set by parse step
  const p = data?.identity?.photo_path?.value;
  if (p && typeof p === "string" && p.trim()) return { kind: "path", value: p.trim() };

  // Fallback to any b64 photo captured from docs
  const b64 = data?.identity?.photo_b64?.value;
  if (b64 && typeof b64 === "string" && b64.trim()) return { kind: "b64", value: b64.trim() };

  // Final fallback: look in session folder for "passport.ext"
  return findPassportInSession(sessionId);
}

// Find a likely marksheet image in session if not explicitly set
function findMarksheetInSession(sessionId) {
  try {
    const dir = path.join(uploadsRoot, sessionId);
    if (!fs.existsSync(dir)) return null;
    const names = fs.readdirSync(dir).filter(n => /\.(png|jpg|jpeg|webp)$/i.test(n));
    const withoutPassport = names.filter(n => !/^passport\.(jpg|jpeg|png|webp)$/i.test(n));

    if (withoutPassport.length === 0) return null;

    // Prefer names that strongly indicate 12th marksheet
    const preferred =
      withoutPassport.find(n => /mark|12|hsc|board|cbse|bseb/i.test(n)) ||
      withoutPassport[0];

    return { kind: "path", value: path.join(dir, preferred) };
  } catch {
    return null;
  }
}

function resolveMarksheet(data, sessionId) {
  // Prefer explicit b64/path set by parse step
  const b64 = data?.education?.[0]?.marksheet_image_b64?.value;
  if (b64 && typeof b64 === "string" && b64.trim()) return { kind: "b64", value: b64.trim() };

  const p = data?.education?.[0]?.marksheet_image_path?.value;
  if (p && typeof p === "string" && p.trim()) return { kind: "path", value: p.trim() };

  // Fallback to session scan
  return findMarksheetInSession(sessionId);
}

// ---------- Route ----------
r.post("/", async (req, res) => {
  try {
    const { sessionId, candidate } = req.body;

    // Validate payload; Zod keeps our new keys now
    const parsed = CandidateSchema.safeParse(candidate);
    if (!parsed.success) {
      return res.status(400).json({ error: "Invalid candidate" });
    }
    const data = parsed.data;

    // Locality via OpenAI using PIN
    const pinRaw = data.address?.pincode?.value || "";
    const pin = String(pinRaw || "").trim();
    const locality = await getLocalityFromPin(pin);

    // Nearest center
    const nearest = findNearestCenter(pin, locality);
    const nearestCenterName = nearest?.name || "N/A";

    // Face verification (consent required) — now robust with fallbacks
    const hasConsent = !!data?.audit?.consent_captured;
    const passportImg = resolvePassport(data, sessionId);
    const marksheetImg = resolveMarksheet(data, sessionId);

    let photoVerified = "Skipped";
    let photoVerifyConfidence = "";
    let passportImageRef = "";

    // For Excel: store path or data URL as a reference
    if (passportImg?.kind === "path") {
      passportImageRef = passportImg.value;
    } else if (passportImg?.kind === "b64") {
      passportImageRef = passportImg.value.startsWith("data:image/")
        ? passportImg.value
        : `data:image/jpeg;base64,${passportImg.value}`;
    }

    if (hasConsent && passportImg && marksheetImg) {
      try {
        // We pass the WHOLE marksheet image; GPT-4o can still match faces present on the doc.
        const result = await verifyFaces(passportImg.value, marksheetImg.value);
        photoVerified = result.verified ? "Yes" : "No";

        const conf = typeof result.confidence === "number" ? result.confidence : 0;
        photoVerifyConfidence = conf <= 1 ? (conf * 100).toFixed(2) : conf.toFixed(2);
      } catch (e) {
        console.error("PHOTO VERIFY ERROR:", e.message);
        photoVerified = "Error";
        photoVerifyConfidence = "";
      }
    } else {
      photoVerified = hasConsent ? "Skipped - Missing Image(s)" : "Skipped - No Consent";
      photoVerifyConfidence = "";
    }

    // Voice recording path (from session uploads)
    const voiceRecordingPath = findVoiceInSession(sessionId);

    // Build summary
    const summaryText = await buildSummary(data, nearestCenterName);

    // Excel write
    ensureExcel();
    const wb = XLSX.readFile(excelPath);
    ensureSheet(wb, "Students");
    const ws = wb.Sheets["Students"];

    const cert = data.skills_certifications?.[0] || {};

    const row = {
      Student_ID: sessionId,
      Full_Name: data.identity.full_name?.value || "",
      Date_of_Birth: data.identity.dob?.value || "",
      Guardian: data.identity.guardian?.value || "",
      Aadhaar_Last4: data.ids.aadhaar_last4?.value || "",
      PAN: data.ids.pan?.value || "",
      Address: data.address.full_address?.value || "",
      Pincode: pin,

      Education_Level: data.education?.[0]?.level || "",
      Exam_Year: data.education?.[0]?.exam_year?.value || "",
      Roll_Number: data.education?.[0]?.roll_or_enrollment?.value || "",
      Marks: data.education?.[0]?.cgpa_or_percent?.value || "",

      // Certificate columns
      Certificate_Title: cert.certificate_title?.value || "",
      Certificate_Issuer: cert.issuing_org?.value || cert.issuer?.value || "",
      Certificate_ID: cert.cert_id?.value || "",
      Certificate_IssueDate: cert.issue_date?.value || "",
      Skill_Detected: cert.skill_detected?.value || "",
      Certificate_Score: cert.grade_or_score?.value || "",

      // Center & locality resolution outputs
      Nearest_Center: nearestCenterName,
      Nearest_Center_Pincode: nearest?.pincode || "",
      Resolved_Locality: locality.locality || "",
      Resolved_City: locality.city || "",
      Resolved_State: locality.state || "",

      // Voice recording
      Voice_Recording_Path: voiceRecordingPath,

      // Face verification outputs
      Passport_Image_Ref: passportImageRef,                // path or data URL
      Photo_Verified: photoVerified,                       // Yes | No | Skipped - ...
      Photo_Verify_ConfidencePct: photoVerifyConfidence,   // "95.23"

      // AI-generated summary
      Summary: summaryText
    };

    const existing = XLSX.utils.sheet_to_json(ws);
    existing.push(row);

    const newWS = XLSX.utils.json_to_sheet(existing);
    wb.Sheets["Students"] = newWS;

    XLSX.writeFile(wb, excelPath);

    res.json({
      ok: true,
      result: {
        photoVerified,
        photoVerifyConfidencePct: photoVerifyConfidence,
        voiceRecordingPath
      }
    });
  } catch (err) {
    console.error("FINALIZE ERROR:", err);
    res.status(500).json({ error: err.message });
  }
});

export default r;