// server/openaiClient.js
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";
import OpenAI from "openai";

// Ensure .env loads from project root
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.resolve(__dirname, ".."); // one level up from /server
dotenv.config({ path: path.join(projectRoot, ".env") });

const endpoint   = process.env.AZURE_OPENAI_ENDPOINT;     // https://<resource>.openai.azure.com
const deployment = process.env.AZURE_OPENAI_DEPLOYMENT;   // e.g., gpt-4o or gpt-4o-mini
const apiVersion = process.env.AZURE_OPENAI_API_VERSION;  // e.g., 2024-10-01-preview
const key        = process.env.AZURE_OPENAI_API_KEY;      // Azure OpenAI key

console.log("Azure OpenAI in use:", { endpoint, deployment, apiVersion });

if (!endpoint || !deployment || !apiVersion || !key) {
  throw new Error("Missing Azure OpenAI config (.env): AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_DEPLOYMENT, AZURE_OPENAI_API_VERSION, AZURE_OPENAI_API_KEY");
}

const client = new OpenAI({
  apiKey: key,
  baseURL: `${endpoint}/openai/deployments/${deployment}`,
  defaultQuery: { "api-version": apiVersion }
});

export default client;