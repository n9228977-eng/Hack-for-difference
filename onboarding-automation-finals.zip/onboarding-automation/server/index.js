import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import dotenv from "dotenv";
import cors from "cors";

import healthRoute from "./routes/health.js";
import registerRoute from "./routes/register.js";
import uploadRoute from "./routes/upload.js";
import parseRoute from "./routes/parse.js";
import finalizeRoute from "./routes/finalize.js";

dotenv.config();

const app = express();
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true }));
app.use(cors());

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Serve static frontend
app.use("/", express.static(path.join(__dirname, "..", "web")));

app.use("/api/health", healthRoute);
app.use("/api/register", registerRoute);
app.use("/api/upload", uploadRoute);
app.use("/api/parse", parseRoute);
app.use("/api/finalize", finalizeRoute);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`✅ Onboarding demo running at http://localhost:${PORT}`);
});
