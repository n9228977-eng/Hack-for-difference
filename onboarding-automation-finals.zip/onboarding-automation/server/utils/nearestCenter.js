// utils/nearestCenter.js
import { trainingCenters } from "../data/trainingCenters.js";

/**
 * Optional helper map: center pincode → city name
 * Edit this to match your org’s naming conventions.
 */
const PIN_TO_CITY = {
  "800001": "Patna",
  "823001": "Gaya",
  "110017": "New Delhi",
  "201301": "Noida",
  "400008": "Mumbai"
};

/**
 * Find the nearest center using signals we have:
 * 1) Exact pincode match
 * 2) City match (via PIN_TO_CITY)
 * 3) PIN prefix heuristic (first 4 → first 3)
 *
 * @param {string} pincode - candidate's pincode
 * @param {{locality:string, city:string, state:string, country:string}} locality - resolved locality object
 * @returns {{ name:string, pincode:string }|null}
 */
export function findNearestCenter(pincode, locality) {
  const pin = String(pincode || "").trim();
  if (!Array.isArray(trainingCenters) || trainingCenters.length === 0) return null;

  // 1) Exact PIN
  const exact = trainingCenters.find(c => String(c.pincode) === pin);
  if (exact) return exact;

  // 2) City match via helper map
  const candidateCity = (locality?.city || "").toLowerCase();
  if (candidateCity) {
    const cityCenters = trainingCenters.filter(c => {
      const city = (PIN_TO_CITY[c.pincode] || "").toLowerCase();
      return city && city === candidateCity;
    });
    if (cityCenters.length) return cityCenters[0];
  }

  // 3) PIN prefix heuristic
  if (/^\d{6}$/.test(pin)) {
    const prefix4 = pin.slice(0, 4);
    const byPrefix4 = trainingCenters.find(c => String(c.pincode).startsWith(prefix4));
    if (byPrefix4) return byPrefix4;

    const prefix3 = pin.slice(0, 3);
    const byPrefix3 = trainingCenters.find(c => String(c.pincode).startsWith(prefix3));
    if (byPrefix3) return byPrefix3;
  }

  // 4) Fallback
  return trainingCenters[0] || null;
}