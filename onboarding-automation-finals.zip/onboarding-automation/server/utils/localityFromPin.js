// utils/localityFromPin.js
import client from "../openaiClient.js";

/**
 * Resolve locality/city/state for an Indian PIN using Azure OpenAI.
 * If uncertain or invalid PIN, returns empty strings (country defaults to India).
 */
export async function getLocalityFromPin(pincode) {
  const pin = String(pincode || "").trim();
  const result = { locality: "", city: "", state: "", country: "India" };

  if (!/^\d{6}$/.test(pin)) return result;

  const system = "You are an address resolver for Indian PIN codes. If unsure, leave fields empty. Return only JSON with keys: locality, city, state, country.";
  const user = `PIN: ${pin}. Return only JSON. Example: {"locality":"Connaught Place","city":"New Delhi","state":"Delhi","country":"India"}`;

  try {
    const resp = await client.chat.completions.create({
      model: process.env.AZURE_OPENAI_DEPLOYMENT,
      temperature: 0.0,
      max_tokens: 80,
      // If your Azure model supports structured output, keep this:
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: system },
        { role: "user", content: user }
      ]
    });

    const text = resp?.choices?.[0]?.message?.content ?? "{}";
    const parsed = JSON.parse(text);
    return {
      locality: parsed.locality || "",
      city: parsed.city || "",
      state: parsed.state || "",
      country: parsed.country || "India"
    };
  } catch (e) {
    console.error("PIN locality resolution error:", e.message);
    return result;
  }
}
