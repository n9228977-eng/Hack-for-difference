// utils/faceVerify.js
import fs from "fs";
import client from "../openaiClient.js";

function isDataUrl(s) {
  return typeof s === "string" && s.startsWith("data:image/");
}

function isBase64Raw(s) {
  return (
    typeof s === "string" &&
    !s.startsWith("data:image/") &&
    /^[A-Za-z0-9+/=\r\n]+$/.test(s.trim())
  );
}

function toBuffer(imageRef) {
  if (!imageRef) return null;
  if (isDataUrl(imageRef)) {
    const base64 = imageRef.split(",")[1];
    return Buffer.from(base64, "base64");
  }
  if (isBase64Raw(imageRef)) {
    return Buffer.from(imageRef.trim(), "base64");
  }
  return fs.existsSync(imageRef) ? fs.readFileSync(imageRef) : null;
}

function toDataUrl(imageRef) {
  if (!imageRef) return null;
  if (isDataUrl(imageRef)) return imageRef;
  if (isBase64Raw(imageRef)) return `data:image/jpeg;base64,${imageRef.trim()}`;
  const buf = toBuffer(imageRef);
  return buf ? `data:image/jpeg;base64,${buf.toString("base64")}` : null;
}

/**
 * Verify if two images are the same person using Azure OpenAI (vision).
 * Uses correct content types: "text" and "image_url".
 *
 * @param {string} passportRef - path, data URL, or raw base64
 * @param {string} marksheetRef - path, data URL, or raw base64
 * @returns {Promise<{verified:boolean, confidence:number, reason?:string}>}
 */
export async function verifyFaces(passportRef, marksheetRef) {
  try {
    const pDataUrl = toDataUrl(passportRef);
    const mDataUrl = toDataUrl(marksheetRef);
    if (!pDataUrl || !mDataUrl) {
      return { verified: false, confidence: 0, reason: "missing_image_data" };
    }

    const system =
      "You are a conservative identity-check assistant. Compare two faces and return structured JSON only. If faces are unclear, occluded, or low-res, reduce confidence.";
    const instruction = `Compare the passport-size portrait (image #1) with the portrait visible on a 12th marksheet (image #2).
Return ONLY JSON with keys: {"same_person": true|false, "confidence": number between 0 and 1}.
Be strict: if uncertain, set "same_person": false and confidence ≤ 0.5.`;

    const messages = [
      { role: "system", content: system },
      {
        role: "user",
        content: [
          { type: "text", text: instruction },                // <-- correct
          { type: "image_url", image_url: { url: pDataUrl }}, // <-- correct
          { type: "image_url", image_url: { url: mDataUrl }}  // <-- correct
        ]
      }
    ];

    const resp = await client.chat.completions.create({
      model: process.env.AZURE_OPENAI_DEPLOYMENT, // e.g., gpt-4o or gpt-4o-mini
      temperature: 0.0,
      max_tokens: 80,
      // If your deployment errors on response_format, comment/remove this line:
      response_format: { type: "json_object" },
      messages
    });

    const raw = resp?.choices?.[0]?.message?.content ?? "{}";
    let parsed = {};
    try {
      parsed = JSON.parse(raw);
    } catch {
      parsed = {};
    }

    const same = !!parsed.same_person;
    const conf = typeof parsed.confidence === "number" ? parsed.confidence : 0;

    // Local debug (only local variables!)
    console.log("verifyFaces result:", { same_person: same, confidence: conf });

    return { verified: same, confidence: conf };
  } catch (e) {
    console.error("verifyFaces(OpenAI) error:", e.message);
    return { verified: false, confidence: 0, reason: "exception" };
  }
}