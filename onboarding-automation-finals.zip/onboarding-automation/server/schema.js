import { z } from "zod";

export const CandidateSchema = z.object({
  identity: z.object({
    full_name: z.object({ value: z.string().nullable(), source: z.string().nullable(), confidence: z.number().optional() }),
    dob: z.object({ value: z.string().nullable(), source: z.string().nullable(), confidence: z.number().optional() }),
    gender: z.object({ value: z.string().nullable(), source: z.string().nullable(), confidence: z.number().optional() }),
    photo_b64: z.object({ value: z.string().nullable(), source: z.string().nullable(), confidence: z.number().optional() }),

    // NEW: persist the Step-0 passport photo file path
    photo_path: z.object({
      value: z.string().nullable(),
      source: z.string().nullable(),
      confidence: z.number().optional()
    }).optional(),

    // optional guardian injected from basic step
    guardian: z.object({ value: z.string().nullable(), source: z.string().nullable(), confidence: z.number().optional() }).optional()
  }),

  ids: z.object({
    aadhaar_last4: z.object({ value: z.string().nullable(), source: z.string().nullable(), confidence: z.number().optional() }),
    pan: z.object({ value: z.string().nullable(), source: z.string().nullable(), confidence: z.number().optional() }),
    dl_number: z.object({ value: z.string().nullable(), source: z.string().nullable(), confidence: z.number().optional() }),
    epic_number: z.object({ value: z.string().nullable(), source: z.string().nullable(), confidence: z.number().optional() }),
    passport_no: z.object({ value: z.string().nullable(), source: z.string().nullable(), confidence: z.number().optional() })
  }),

  address: z.object({
    full_address: z.object({ value: z.string().nullable(), source: z.string().nullable(), confidence: z.number().optional() }),
    pincode: z.object({ value: z.string().nullable(), source: z.string().nullable(), confidence: z.number().optional() }),
    state: z.object({ value: z.string().nullable(), source: z.string().nullable(), confidence: z.number().optional() }),
    district: z.object({ value: z.string().nullable(), source: z.string().nullable(), confidence: z.number().optional() })
  }),

  education: z.array(z.object({
    level: z.string().nullable(),
    board_university: z.object({ value: z.string().nullable(), source: z.string().nullable(), confidence: z.number().optional() }),
    exam_year: z.object({ value: z.string().nullable(), source: z.string().nullable(), confidence: z.number().optional() }),
    roll_or_enrollment: z.object({ value: z.string().nullable(), source: z.string().nullable(), confidence: z.number().optional() }),
    cgpa_or_percent: z.object({ value: z.string().nullable(), source: z.string().nullable(), confidence: z.number().optional() }),

    // NEW: persist marksheet image references if parser/logic sets them
    marksheet_image_path: z.object({
      value: z.string().nullable(),
      source: z.string().nullable(),
      confidence: z.number().optional()
    }).optional(),
    marksheet_image_b64: z.object({
      value: z.string().nullable(),
      source: z.string().nullable(),
      confidence: z.number().optional()
    }).optional()
  })).default([]),

  // 🔹 Enhanced certificate object
  skills_certifications: z.array(z.object({
    certificate_title: z.object({ value: z.string().nullable(), source: z.string().nullable(), confidence: z.number().optional() }).optional(),
    issuing_org: z.object({ value: z.string().nullable(), source: z.string().nullable(), confidence: z.number().optional() }).optional(),
    issue_date: z.object({ value: z.string().nullable(), source: z.string().nullable(), confidence: z.number().optional() }).optional(),
    cert_id: z.object({ value: z.string().nullable(), source: z.string().nullable(), confidence: z.number().optional() }).optional(),
    skill_detected: z.object({ value: z.string().nullable(), source: z.string().nullable(), confidence: z.number().optional() }).optional(),
    grade_or_score: z.object({ value: z.string().nullable(), source: z.string().nullable(), confidence: z.number().optional() }).optional(),

    // keep earlier keys if your flows used them
    issuer: z.object({ value: z.string().nullable(), source: z.string().nullable(), confidence: z.number().optional() }).optional(),
    qp_code: z.object({ value: z.string().nullable(), source: z.string().nullable(), confidence: z.number().optional() }).optional(),
    nsqf_level: z.object({ value: z.string().nullable(), source: z.string().nullable(), confidence: z.number().optional() }).optional()
  })).default([]),

  financial_optional: z.object({
    bank_name: z.object({ value: z.string().nullable(), source: z.string().nullable(), confidence: z.number().optional() }).optional(),
    branch: z.object({ value: z.string().nullable(), source: z.string().nullable(), confidence: z.number().optional() }).optional(),
    ifsc: z.object({ value: z.string().nullable(), source: z.string().nullable(), confidence: z.number().optional() }).optional(),
    account_last4: z.object({ value: z.string().nullable(), source: z.string().nullable(), confidence: z.number().optional() }).optional()
  }).optional(),

  social_protection_optional: z.object({
    e_shram_uan: z.object({ value: z.string().nullable(), source: z.string().nullable(), confidence: z.number().optional() }).optional(),
    apprenticeship_contract_id: z.object({ value: z.string().nullable(), source: z.string().nullable(), confidence: z.number().optional() }).optional()
  }).optional(),

  audit: z.object({
    doc_sources: z.array(z.string()).default([]),
    created_at: z.string(),
    consent_captured: z.boolean()
  })
});

export const emptyCandidate = () => ({
  identity: {
    full_name: { value: null, source: null },
    dob: { value: null, source: null },
    gender: { value: null, source: null },
    photo_b64: { value: null, source: null },
    // NEW
    photo_path: { value: null, source: null }
  },
  ids: {
    aadhaar_last4: { value: null, source: null },
    pan: { value: null, source: null },
    dl_number: { value: null, source: null },
    epic_number: { value: null, source: null },
    passport_no: { value: null, source: null }
  },
  address: {
    full_address: { value: null, source: null },
    pincode: { value: null, source: null },
    state: { value: null, source: null },
    district: { value: null, source: null }
  },
  education: [{
    level: null,
    board_university: { value: null, source: null },
    exam_year: { value: null, source: null },
    roll_or_enrollment: { value: null, source: null },
    cgpa_or_percent: { value: null, source: null },
    // NEW
    marksheet_image_path: { value: null, source: null },
    marksheet_image_b64: { value: null, source: null }
  }],
  skills_certifications: [],
  financial_optional: {},
  social_protection_optional: {},
  audit: { doc_sources: [], created_at: new Date().toISOString(), consent_captured: false }
});