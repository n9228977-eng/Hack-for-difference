// Example – replace these with your real centre locations
export const trainingCenters = [
  { name: "Patna Training Hub", pincode: "800001" },
  { name: "Gaya Skill Center",  pincode: "823001" },
  { name: "Delhi Saket Center", pincode: "110017" },
  { name: "Noida Sector 62 Center", pincode: "201301" },
  { name: "Mumbai Central Center", pincode: "400008" }
];