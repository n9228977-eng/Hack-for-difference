// server/merge.js
import client from "./openaiClient.js";
import { CandidateSchema, emptyCandidate } from "./schema.js";

/**
 * Extract the largest JSON object from an arbitrary string.
 * Handles cases where the model adds ```json fences or stray text.
 */
function extractJson(text) {
  if (!text) return null;
  const cleaned = text
    .replace(/^```json[\r\n]?/i, "")
    .replace(/^```[\r\n]?/i, "")
    .replace(/```$/i, "")
    .trim();

  if (cleaned.startsWith("{") && cleaned.endsWith("}")) return cleaned;

  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start === -1 || end === -1 || end <= start) return null;
  return cleaned.slice(start, end + 1);
}

const SYSTEM_MERGE = `
You are a strict normalizer. Input: array of partial JSONs from document OCR.
TASK: Merge into the TARGET schema. RULES:
- For each field, set { "value": ..., "source": ..., "confidence": ... } with confidence 0..1.
- Prefer the highest-confidence value across sources.
- If absent, set "value": null and "confidence": 0.0 (do not invent).
- Never include full Aadhaar or bank numbers; only last4.
- Respond with ONE STRICT JSON object only. No markdown fences, no comments, no prose.

TARGET KEYS:
identity{full_name,dob,gender,photo_b64,guardian},
ids{aadhaar_last4,pan,dl_number,epic_number,passport_no},
address{full_address,pincode,state,district},
education[
  {level,board_university,exam_year,roll_or_enrollment,cgpa_or_percent}
],
skills_certifications[
  {certificate_title,issuing_org,issue_date,cert_id,skill_detected,grade_or_score,issuer,qp_code,nsqf_level}
],
financial_optional{bank_name,branch,ifsc,account_last4},
social_protection_optional{e_shram_uan,apprenticeship_contract_id},
audit{doc_sources,created_at,consent_captured}
`;

export async function mergePartials(partials, audit) {
  try {
    const userPayload = JSON.stringify({ partials, audit });

    const resp = await client.chat.completions.create({
      model: process.env.AZURE_OPENAI_DEPLOYMENT, // gpt-4o or gpt-4o-mini
      temperature: 0,
      max_tokens: 1800,
      // Nudge the model to return pure JSON; if not supported the call still succeeds.
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: SYSTEM_MERGE },  // <-- correct constant
        { role: "user", content: userPayload }
      ]
    });

    const raw = (resp.choices?.[0]?.message?.content || "").trim();
    const jsonText = extractJson(raw);

    if (!jsonText) {
      console.warn("MERGE: model did not return JSON; falling back to emptyCandidate(). First 240 chars:", raw.slice(0, 240));
      const base = emptyCandidate();
      base.audit = audit;
      return base;
    }

    let merged;
    try {
      merged = JSON.parse(jsonText);
    } catch (e) {
      console.warn("MERGE: JSON.parse() failed; falling back. First 240 chars:", jsonText.slice(0, 240));
      const base = emptyCandidate();
      base.audit = audit;
      return base;
    }

    const safe = CandidateSchema.safeParse(merged);
    if (!safe.success) {
      console.warn("MERGE: schema validation failed; falling back to emptyCandidate(). Issues:", safe.error?.errors?.map(e => e.message));
      const base = emptyCandidate();
      base.audit = audit;
      return base;
    }

    // Preserve audit supplied by caller
    safe.data.audit = audit;
    return safe.data;
  } catch (err) {
    console.error("MERGE ERROR:", err);
    const base = emptyCandidate();
    base.audit = audit;
    return base;
  }
}