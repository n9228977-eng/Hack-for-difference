// -------------------------
// onboarding-demo web/app.js (robust education mapping + logging)
// -------------------------

let sessionId = null;
let uploaded = [];
let currentCandidate = null;

// Steps
const S0 = document.getElementById("step-0");
const S1 = document.getElementById("step-1");
const S2 = document.getElementById("step-2");
const S3 = document.getElementById("step-3");

// --- Recording state (Step-0) ---
let mediaRecorder = null;
let audioChunks = [];
let pendingAudioBlob = null;

// DOM for recording (Step-0)
const btnRecordStart = document.getElementById("btn-record-start");
const btnRecordStop  = document.getElementById("btn-record-stop");
const recordingStatus = document.getElementById("recording-status");

// Buttons (flow)
const btnBasicNext   = document.getElementById("btn-basic-next");
const btnConsentNext = document.getElementById("btn-consent-next");
const btnBack0       = document.getElementById("btn-back-0");
const btnBack1       = document.getElementById("btn-back-1");
const btnBack2       = document.getElementById("btn-back-2");
const btnParse       = document.getElementById("btn-parse");
const btnFinish      = document.getElementById("btn-finish");

// Basic details inputs (Step-0)
const basicFullName  = document.getElementById("basic_fullname");
const basicDob       = document.getElementById("basic_dob");
const basicGuardian  = document.getElementById("basic_guardian");

// Consent checkbox (Step-1)
const consent        = document.getElementById("consent");

// Upload controls (Step-2)
const docs           = document.getElementById("docs");
const passportPhoto  = document.getElementById("passport_photo"); // moved to Step-2
const uploadStatus   = document.getElementById("upload-status");

// Final step status
const finalMsg       = document.getElementById("final-msg");

// Local holder for Step-0 values (used as fallback)
let basicFormData = {};

// Navigation helper
function goto(step) {
  [S0, S1, S2, S3].forEach(s => s.classList.remove("active"));
  step.classList.add("active");
}

// Ensure we start on Step-0
goto(S0);

// -------------------------
// Step-0: Basic details
// -------------------------

// Defensive recording start (secure context + feature detection + MIME fallback)
btnRecordStart.addEventListener("click", async () => {
  try {
    // Secure context is required (HTTPS or http://localhost)
    if (!window.isSecureContext) {
      recordingStatus.textContent = "⚠️ Microphone requires HTTPS or http://localhost.";
      return;
    }

    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      recordingStatus.textContent = "⚠️ getUserMedia not supported by this browser.";
      return;
    }

    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });

    // MediaRecorder support check
    if (typeof MediaRecorder === "undefined") {
      recordingStatus.textContent = "⚠️ MediaRecorder not supported; try latest Chrome or Edge.";
      return;
    }

    // Try supported MIME types for cross-browser compatibility
    const mimeCandidates = [
      "audio/webm;codecs=opus",
      "audio/webm",
      "audio/ogg;codecs=opus",
      "audio/ogg",
      "audio/mp4"
    ];
    let selectedMime = "";
    for (const m of mimeCandidates) {
      if (MediaRecorder.isTypeSupported?.(m)) {
        selectedMime = m;
        break;
      }
    }

    mediaRecorder = selectedMime
      ? new MediaRecorder(stream, { mimeType: selectedMime })
      : new MediaRecorder(stream); // browser decides

    audioChunks = [];

    mediaRecorder.ondataavailable = (e) => {
      if (e.data && e.data.size > 0) audioChunks.push(e.data);
    };

    mediaRecorder.onstart = () => {
      recordingStatus.textContent = `🎤 Recording started (${selectedMime || "default"}). Speak about your interests and goals.`;
      btnRecordStart.style.display = "none";
      btnRecordStop.style.display = "inline-block";
    };

    mediaRecorder.onstop = () => {
      const type = selectedMime || "audio/webm";
      const blob = new Blob(audioChunks, { type });
      pendingAudioBlob = blob; // store until we have sessionId
      recordingStatus.textContent = "✅ Recording captured. It will be saved after you give consent.";
      btnRecordStart.style.display = "inline-block";
      btnRecordStop.style.display = "none";

      // Stop microphone tracks to release device
      stream.getTracks().forEach(t => t.stop());
    };

    mediaRecorder.start();
  } catch (err) {
    console.error("Mic error:", err);
    if (err && (err.name === "NotAllowedError" || err.name === "SecurityError")) {
      recordingStatus.textContent = "⚠️ Permission denied. Please allow microphone access in the browser site settings.";
    } else if (err && err.name === "NotFoundError") {
      recordingStatus.textContent = "⚠️ No microphone found.";
    } else {
      recordingStatus.textContent = "⚠️ Microphone access denied or unavailable.";
    }
  }
});

btnRecordStop.addEventListener("click", () => {
  try {
    if (mediaRecorder && mediaRecorder.state === "recording") {
      mediaRecorder.stop();
    }
  } catch (err) {
    console.error("Stop error:", err);
  }
});

btnBasicNext.addEventListener("click", () => {
  if (!basicFullName.value.trim() || !basicDob.value || !basicGuardian.value.trim()) {
    alert("Please fill all basic details first.");
    return;
  }

  basicFormData = {
    full_name: basicFullName.value.trim(),
    dob: basicDob.value,               // ISO yyyy-mm-dd
    guardian: basicGuardian.value.trim()
  };
  goto(S1); // Move to consent step
});

// -------------------------
// Step-1: Consent
// -------------------------
consent.addEventListener("change", () => {
  btnConsentNext.disabled = !consent.checked;
});

btnConsentNext.addEventListener("click", async () => {
  try {
    // Create backend session
    const res = await fetch("/api/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ consent: true })
    });

    const data = await res.json();
    sessionId = data.sessionId;

    // Immediately upload recorded audio if we have any
    try {
      if (pendingAudioBlob && sessionId) {
        const fdAudio = new FormData();
        fdAudio.append("sessionId", sessionId);
        fdAudio.append("voice_recording", pendingAudioBlob, "voice.webm");

        await fetch("/api/upload", { method: "POST", body: fdAudio });
        recordingStatus.textContent = "🎧 Voice recording saved.";
      }
    } catch (e) {
      console.error("Audio upload failed:", e);
      recordingStatus.textContent = "⚠️ Failed to save voice recording (network error).";
    }

    // NOTE: Passport photo is NO LONGER uploaded here; it is uploaded in Step-2
    goto(S2); // upload step
  } catch (err) {
    console.error("Consent/session error:", err);
    alert("Unable to create session. Please try again.");
  }
});

// Back from Step-1 to Step-0
btnBack0.addEventListener("click", () => goto(S0));

// -------------------------
// Step-2: Upload (passport + other docs)
// -------------------------
async function uploadAllSelectedFiles() {
  if (!sessionId) {
    alert("Session not ready yet. Please complete consent.");
    return;
  }

  const fd = new FormData();
  fd.append("sessionId", sessionId);

  // Append passport photo if selected
  if (passportPhoto.files && passportPhoto.files[0]) {
    fd.append("passport_photo", passportPhoto.files[0]);
  }

  // Append other docs
  if (docs.files && docs.files.length > 0) {
    for (const f of docs.files) fd.append("docs", f);
  }

  uploadStatus.textContent = "Uploading...";
  try {
    const res = await fetch("/api/upload", { method: "POST", body: fd });
    const data = await res.json();

    // Backend returns list of uploaded docs (and passport optionally)
    uploaded = data.uploaded || [];
    const passportOk = data.passportUploaded || (data.uploadedPassport ? true : false);

    // UX message
    const count = uploaded.length + (passportOk ? 1 : 0);
    uploadStatus.textContent = `Uploaded ${count} file(s).`;
    btnParse.disabled = count === 0;
  } catch (err) {
    console.error("Upload error:", err);
    uploadStatus.textContent = "⚠️ Upload failed. Please try again.";
  }
}

// Trigger upload when either input changes (passport or docs)
passportPhoto.addEventListener("change", uploadAllSelectedFiles);
docs.addEventListener("change", uploadAllSelectedFiles);

// ---------- Utilities: defend against primitives/empties ----------
function ensureIdentity(c) {
  c.identity = c.identity || {};
  const makeKV = (obj, key) => {
    if (!obj[key] || typeof obj[key] !== "object") obj[key] = { value: obj[key] ?? null, source: null, confidence: 0 };
  };
  makeKV(c.identity, "full_name");
  makeKV(c.identity, "dob");
  makeKV(c.identity, "gender");
  makeKV(c.identity, "photo_b64");
  if (!c.identity.guardian || typeof c.identity.guardian !== "object") {
    c.identity.guardian = { value: null, source: "user_input", confidence: 1 };
  }
}

function ensureIds(c) {
  c.ids = c.ids || {};
  const makeKV = (obj, key) => {
    if (!obj[key] || typeof obj[key] !== "object") obj[key] = { value: obj[key] ?? null, source: null, confidence: 0 };
  };
  ["aadhaar_last4","pan","dl_number","epic_number","passport_no"].forEach(k => makeKV(c.ids, k));
}

function ensureAddress(c) {
  c.address = c.address || {};
  const makeKV = (obj, key) => {
    if (!obj[key] || typeof obj[key] !== "object") obj[key] = { value: obj[key] ?? null, source: null, confidence: 0 };
  };
  ["full_address","pincode","state","district"].forEach(k => makeKV(c.address, k));
}

function ensureEducation(c) {
  if (!Array.isArray(c.education)) c.education = [];
  if (c.education.length === 0) {
    c.education.push({
      level: null,
      board_university:   { value: null, source: null, confidence: 0 },
      exam_year:          { value: null, source: null, confidence: 0 },
      roll_or_enrollment: { value: null, source: null, confidence: 0 },
      cgpa_or_percent:    { value: null, source: null, confidence: 0 }
    });
  } else {
    const ed = c.education[0];
    if (!ed.board_university || typeof ed.board_university !== "object")   ed.board_university   = { value: ed.board_university ?? null, source: null, confidence: 0 };
    if (!ed.exam_year || typeof ed.exam_year !== "object")                 ed.exam_year          = { value: ed.exam_year ?? null, source: null, confidence: 0 };
    if (!ed.roll_or_enrollment || typeof ed.roll_or_enrollment !== "object") ed.roll_or_enrollment = { value: ed.roll_or_enrollment ?? null, source: null, confidence: 0 };
    if (!ed.cgpa_or_percent || typeof ed.cgpa_or_percent !== "object")     ed.cgpa_or_percent    = { value: ed.cgpa_or_percent ?? null, source: null, confidence: 0 };
    if (typeof ed.level === "undefined") ed.level = null;
  }
}

function ensureCertificate(c) {
  if (!Array.isArray(c.skills_certifications)) c.skills_certifications = [];
  if (c.skills_certifications.length === 0) {
    c.skills_certifications.push({
      certificate_title: { value: null, source: null, confidence: 0 },
      issuing_org:      { value: null, source: null, confidence: 0 },
      issue_date:       { value: null, source: null, confidence: 0 },
      cert_id:          { value: null, source: null, confidence: 0 },
      skill_detected:   { value: null, source: null, confidence: 0 },
      grade_or_score:   { value: null, source: null, confidence: 0 }
    });
  } else {
    const c0 = c.skills_certifications[0];
    const fix = (key) => {
      if (!c0[key] || typeof c0[key] !== "object") c0[key] = { value: c0[key] ?? null, source: null, confidence: 0 };
    };
    ["certificate_title","issuing_org","issue_date","cert_id","skill_detected","grade_or_score"].forEach(fix);
  }
}

// Trigger extraction and populate live form
btnParse.addEventListener("click", async () => {
  uploadStatus.textContent = "Extracting with Azure OpenAI… (this can take a moment)";
  try {
    const res = await fetch("/api/parse", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({ sessionId })
    });
    const data = await res.json();

    const candidate = data.candidate || {};
    // Log full payload to inspect education values
    console.log("PARSED CANDIDATE:", candidate);
    console.log("EDUCATION RAW:", candidate?.education);

    // Ensure strong structure everywhere
    ensureIdentity(candidate);
    ensureIds(candidate);
    ensureAddress(candidate);
    ensureEducation(candidate);
    ensureCertificate(candidate);

    currentCandidate = candidate;

    // ---------- Identity ----------
    document.getElementById("f_full_name").value =
      candidate.identity.full_name.value || basicFormData.full_name || "";
    document.getElementById("f_dob").value =
      candidate.identity.dob.value || basicFormData.dob || "";
    document.getElementById("f_gender").value =
      candidate.identity.gender.value || "";

    // ---------- IDs ----------
    document.getElementById("f_aadhaar").value = candidate.ids.aadhaar_last4.value || "";
    document.getElementById("f_pan").value     = candidate.ids.pan.value || "";
    document.getElementById("f_dl").value      = candidate.ids.dl_number.value || "";
    document.getElementById("f_epic").value    = candidate.ids.epic_number.value || "";
    document.getElementById("f_passport").value= candidate.ids.passport_no.value || "";

    // ---------- Address ----------
    document.getElementById("f_address").value  = candidate.address.full_address.value || "";
    document.getElementById("f_pincode").value  = candidate.address.pincode.value || "";
    document.getElementById("f_state").value    = candidate.address.state.value || "";
    document.getElementById("f_district").value = candidate.address.district.value || "";

    // ---------- Education (first record; safe) ----------
    const ed = candidate.education[0];
    console.log("EDUCATION NORMALIZED:", ed);

    document.getElementById("f_ed_level").value = ed.level || "";

    // Prefer nested .value; if OCR returned primitive, we already wrapped it above
    document.getElementById("f_ed_board").value = ed.board_university.value || "";
    document.getElementById("f_ed_year").value  = ed.exam_year.value || "";
    document.getElementById("f_ed_roll").value  = ed.roll_or_enrollment.value || "";
    document.getElementById("f_ed_marks").value = ed.cgpa_or_percent.value || "";

    // ---------- Certificate (first record; safe) ----------
    const cert = candidate.skills_certifications[0];
    document.getElementById("f_cert_title").value = cert.certificate_title.value || "";
    document.getElementById("f_cert_org").value   = cert.issuing_org.value || "";
    document.getElementById("f_cert_date").value  = cert.issue_date.value || "";
    document.getElementById("f_cert_id").value    = cert.cert_id.value || "";
    document.getElementById("f_cert_skill").value = cert.skill_detected.value || "";
    document.getElementById("f_cert_score").value = cert.grade_or_score.value || "";

    // Move to review form
    goto(S3);
  } catch (err) {
    console.error("Parse error:", err);
    uploadStatus.textContent = "⚠️ Extraction failed. Please try again.";
  }
});

// Back buttons
btnBack1.addEventListener("click", () => goto(S1));
btnBack2.addEventListener("click", () => goto(S2));

// -------------------------
// Finish: Collect form fields and submit
// -------------------------
btnFinish.addEventListener("click", async () => {
  finalMsg.textContent = "";

  // Safety: ensure we have an object to update
  if (!currentCandidate || typeof currentCandidate !== "object") {
    currentCandidate = {
      identity: { full_name: {value:null}, dob: {value:null}, gender: {value:null}, guardian: {value:null} },
      ids: { aadhaar_last4: {value:null}, pan: {value:null}, dl_number: {value:null}, epic_number: {value:null}, passport_no: {value:null} },
      address: { full_address: {value:null}, pincode: {value:null}, state: {value:null}, district: {value:null} },
      education: [],
      skills_certifications: [],
      audit: { doc_sources: [], created_at: new Date().toISOString(), consent_captured: true }
    };
  }

  const candidate = JSON.parse(JSON.stringify(currentCandidate)); // clone

  // Normalize structure again before writing
  ensureIdentity(candidate);
  ensureIds(candidate);
  ensureAddress(candidate);
  ensureEducation(candidate);
  ensureCertificate(candidate);

  // ---------- Identity ----------
  candidate.identity.full_name.value = document.getElementById("f_full_name").value || basicFormData.full_name || null;
  candidate.identity.dob.value       = document.getElementById("f_dob").value || basicFormData.dob || null;
  candidate.identity.gender.value    = document.getElementById("f_gender").value || null;
  candidate.identity.guardian.value  = basicFormData.guardian || null;

  // ---------- IDs ----------
  candidate.ids.aadhaar_last4.value = document.getElementById("f_aadhaar").value || null;
  candidate.ids.pan.value           = document.getElementById("f_pan").value || null;
  candidate.ids.dl_number.value     = document.getElementById("f_dl").value || null;
  candidate.ids.epic_number.value   = document.getElementById("f_epic").value || null;
  candidate.ids.passport_no.value   = document.getElementById("f_passport").value || null;

  // ---------- Address ----------
  candidate.address.full_address.value = document.getElementById("f_address").value || null;
  candidate.address.pincode.value      = document.getElementById("f_pincode").value || null;
  candidate.address.state.value        = document.getElementById("f_state").value || null;
  candidate.address.district.value     = document.getElementById("f_district").value || null;

  // ---------- Education (first record; safe) ----------
  candidate.education[0].level                         = document.getElementById("f_ed_level").value || null;
  candidate.education[0].board_university.value        = document.getElementById("f_ed_board").value || null;
  candidate.education[0].exam_year.value               = document.getElementById("f_ed_year").value || null;
  candidate.education[0].roll_or_enrollment.value      = document.getElementById("f_ed_roll").value || null;
  candidate.education[0].cgpa_or_percent.value         = document.getElementById("f_ed_marks").value || null;

  // ---------- Certificate (first record; safe) ----------
  candidate.skills_certifications[0].certificate_title.value = document.getElementById("f_cert_title").value || null;
  candidate.skills_certifications[0].issuing_org.value       = document.getElementById("f_cert_org").value   || null;
  candidate.skills_certifications[0].issue_date.value        = document.getElementById("f_cert_date").value  || null;
  candidate.skills_certifications[0].cert_id.value           = document.getElementById("f_cert_id").value    || null;
  candidate.skills_certifications[0].skill_detected.value    = document.getElementById("f_cert_skill").value || null;
  candidate.skills_certifications[0].grade_or_score.value    = document.getElementById("f_cert_score").value || null;

  // ---------- Submit to backend ----------
  try {
    const res = await fetch("/api/finalize", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({ sessionId, candidate })
    });
    const data = await res.json();
    
    if (data.ok) {
      finalMsg.textContent = "✅ Saved! Your details have been stored in the database.";

      // Set photo verification field
      if (data.result && data.result.photoVerifyConfidencePct !== undefined) {
        document.getElementById("f_photo_verification").value =
          data.result.photoVerifyConfidencePct + "% success";
      } else {
        document.getElementById("f_photo_verification").value = "N/A";
      }
    } else {
      finalMsg.textContent = "Failed to save";
    }
  } catch (e) {
    console.error(e);
    finalMsg.textContent = "Failed to save";
  }
});